#!/usr/bin/env bash

#Поиск тайтла, запись результатов в переменную
searchResults=$(\
curl -s --get\
 --data-urlencode "limit=20"\
 --data-urlencode "f[search]=$1"\
 --data-urlencode "include=id,name.main,episodes_total"\
 "https://api.anilibria.app/api/v1/anime/catalog/releases/?"\
 -H 'accept: application/json'\
 | jq\
)

#Сортировка результатов в три массива
id=($(echo $searchResults | jq '.data[] | .id'))
totalEpisodes=($(echo $searchResults | jq '.data[] | .episodes_total'))
mapfile name < <(echo $searchResults | jq -r '.data[] | .name.main')

#Вывод найденых результатов
for var in ${!id[*]}
do
echo\
 $(($var + 1))\
 ${name[$var]}\
 '['${totalEpisodes[$var]}']'
done

#Запрос номера результата
read -p "Пункт со списка: " chId

#Проверка чтоб номер не превышал количество результатов
if [ $chId -le ${#id[*]} ]; then

  #Запрос номера серии если 2 параметром не указано качество то качество=480
  read -p "Номер серии: " chEpNum q

  #Проверка указано качество или нет
  if [ -z "$q" ]; then

#Если нет - запуск плеера
am start\
 -n com.mxtech.videoplayer.pro/.ActivityScreen\
 -a android.intent.action.VIEW $(\
curl -s --get\
 --data-urlencode 'include=episodes.hls_480'\
 "https://api.anilibria.app/api/v1/anime/releases/${id[$((chId - 1))]}?"\
 -H 'accept: application/json'\
 | jq -r '.episodes[] | .hls_480'\
 | grep /$chEpNum/\
)
exit
  else

#Если указано качество
am start\
 -n com.mxtech.videoplayer.pro/.ActivityScreen\
 -a android.intent.action.VIEW $(\
curl -s --get\
 --data-urlencode "include=episodes.hls_$q"\
 "https://api.anilibria.app/api/v1/anime/releases/${id[$((chId - 1))]}?"\
 -H 'accept: application/json'\
 | jq -r ".episodes[] | .hls_$q"\
 | grep /$chEpNum/$q\
)
exit

  fi
else
  echo "Слишком большое число"
fi

#!/usr/bin/env python3

import requests, json, argparse, subprocess, sys, platform
from pathlib import Path
from pym3u8downloader import M3U8Downloader

#Создание параметров для программы
parser = argparse.ArgumentParser(description='Аниме с Анилибрии')
parser.add_argument('-s', '--search', help="Запрос для поиска")
parser.add_argument('-q', '--quality', default='720', help="Качество, по умолчанию 480")
parser.add_argument('-e', '--episode', type=int, default=0, help="Указать эпизод")
parser.add_argument('-r', '--results', type=int, default=5, help="Количество результатов поиска, по умолчанию 5")
parser.add_argument('-p', '--player', default='mpv', help="Выбор плеера")
parser.add_argument('-o', '--output', default='Anilibria', help="Путь для загрузки")
parser.add_argument('-d', '--download', action="store_true", help='Загрузка видео вместо запуска плеера')
parser.add_argument('-f', '--fast', action="store_true", help='Быстрый запуск')
parser.add_argument('-l', '--latest', action="store_true", help='Открыть последнею просмотренную серию')
parser.add_argument('-t', '--latestTitle', action="store_true", help='Открыть последний тайтл')
args = parser.parse_args()

if 'android' in platform.release():
  args.quality = '480'
  args.player = 'mx'
  args.output = 'storage/movies/Anilibria'

#Создание путей для записи последнего просмотра
cache = Path.home() / '.cache/Anilibria'
latest = cache / 'latest.txt'
latestTitle = cache / 'latestTitle.json'

if not cache.exists():
  cache.mkdir()
if not latest.exists():
  latest.touch()
if not latestTitle.exists():
  latestTitle.touch()

def play(link, name):
  if args.download:
    download = Path.home() / args.output
    if not download.exists():
      download.mkdir()
    forbiddenChars = {'<', '>', ':', '"', '/', '|', '?', '*'}
    for char in name:
      if char in forbiddenChars:
        name = name.replace(char, '_')
    fileName = download / f"{name}.mp4"
    downloader = M3U8Downloader(
    input_file_path=link[:link.find(".m3u8")+5],
    output_file_path = str(fileName))
    downloader.download_playlist()
  else:
    if args.player == 'mpv':
      subprocess.run(["mpv", "--save-position-on-quit", f"--title={name}", link])
    elif args.player == 'mx':
      subprocess.run(["mx", link, name])
    else:
      subprocess.run([args.player, link])
    latest.write_text(link)

#Обработка флага -l
if args.latest:
  play(latest.read_text(), "Последнее")
  sys.exit()

#Обработка флага -t
if args.latestTitle:
  episodes = json.loads(latestTitle.read_text())
  if args.episode == 0:
    for episode in episodes:
      if episode['name'] == None:
        print(episode['ordinal'])
      else:
        print(episode['ordinal'],\
        episode['name'])
    args.episode = int(input('Введите номер: '))
  while len(episodes) < args.episode:
    args.episode = int(input("Слишком большой номер эпизода: "))
  episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  while episodeLink == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
    episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  episodeName = f"Серия {args.episode} ({args.quality})"
  play(episodeLink, episodeName)
  sys.exit()

#Обработка флага -s
if args.search:
  searchPar = {'limit': args.results, 'f[search]': args.search, 'include': 'id,name.main,type.description,episodes_total'}
else:
  searchPar = {'limit': args.results, 'include': 'id,name.main,type.description,episodes_total'}
response = json.loads(requests.get('https://api.anilibria.app/api/v1/anime/catalog/releases/?', params=searchPar).text)
results = response['data']

while len(results) == 0:
  args.search = input('Ничего не найдено (⊙_⊙)\nВведите новый запрос: ')
  searchPar = {'limit': args.results, 'f[search]': args.search, 'include': 'id,name.main,type.description,episodes_total'}
  response = json.loads(requests.get('https://api.anilibria.app/api/v1/anime/catalog/releases/?', params=searchPar).text)
  results = response['data']

#Обработка флага -f
if args.fast:
  counter = 1
  for result in results:
    if result['type']['description'] == 'Фильм':
      print(f"{counter} {result['name']['main']} [{result['type']['description']}]")
    else:
      print(f"{counter} {result['name']['main']} ({result['episodes_total']}) [{result['type']['description']}]")
    counter += 1
  
  titleNumber = int(input("Введите номер тайтла: "))
  while len(results) < titleNumber:
    titleNumber = int(input("Слишком большой номер: "))
  
  if args.episode == 0:
    args.episode = int(input("Введите номер эпизода: "))
  while results[titleNumber - 1]['episodes_total'] < args.episode:
    args.episode = int(input("Слишком большой номер эпизода: "))
  
  title = results[titleNumber - 1]
  titlePar = {'include': 'episodes',\
  'exclude': 'episodes.id,episodes.opening,episodes.ending,episodes.preview,episodes.duration,episodes.rutube_id,episodes.youtube_id,episodes.updated_at,episodes.sort_order,episodes.release_id,episodes.name_english'}
  url = "https://api.anilibria.app/api/v1/anime/releases/" + str(title['id']) + "?"
  episodes = json.loads(requests.get(url, params=titlePar).text)['episodes']
  latestTitle.write_text(json.dumps(episodes))
  episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  while episodeLink == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
    episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  episodeName = f"{title['name']['main']} - Серия {args.episode} ({args.quality})"
  play(episodeLink, episodeName)
  sys.exit()

#Отрисовка списка результатов
counter = 1
for result in results:
  print(counter, " ",\
  result['name']['main'],\
  ' [', result['type']['description'], ']',\
  sep="")
  counter += 1

titleNumber = int(input("Введите номер: "))
while len(results) < titleNumber:
  titleNumber = int(input("Слишком большой номер: "))

title = results[titleNumber - 1]
titlePar = {'include': 'episodes',\
'exclude': 'episodes.id,episodes.opening,episodes.ending,episodes.preview,episodes.duration,episodes.rutube_id,episodes.youtube_id,episodes.updated_at,episodes.sort_order,episodes.release_id,episodes.name_english'}
url = "https://api.anilibria.app/api/v1/anime/releases/" + str(title['id']) + "?"
episodes = json.loads(requests.get(url, params=titlePar).text)['episodes']
latestTitle.write_text(json.dumps(episodes))

#Проверка. Если выбраный тайтл - фильм, запускает просмотр
if title['type']['description'] == 'Фильм':
  episodeLink = episodes[0]['hls_' + args.quality]
  while episodeLink == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
    episodeLink = episodes[0]['hls_' + args.quality]
  episodeName = f"{title['name']['main']} ({args.quality})"
  play(episodeLink, episodeName)

#Если нет отрисовывает список эпизодов
else:
  if args.episode == 0:
    for episode in episodes:
      if episode['name'] == None:
        print(episode['ordinal'])
      else:
        print(episode['ordinal'],\
        episode['name'])
    args.episode = int(input('Введите номер: '))
  while len(episodes) < args.episode:
    args.episode = int(input("Слишком большой номер эпизода: "))
  episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  while episodeLink == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
    episodeLink = episodes[args.episode - 1]['hls_' + args.quality]
  episodeName = f"{title['name']['main']} - Серия {args.episode} ({args.quality})"
  play(episodeLink, episodeName)
#!/usr/bin/env python3

import requests, json, argparse, subprocess, sys
from pathlib import Path

#Создание параметров для программы
parser = argparse.ArgumentParser(description='Аниме с Анилибрии')
parser.add_argument('-s', '--search', help="Запрос для поиска")
parser.add_argument('-q', '--quality', default='480', help="Качество, по умолчанию 480")
parser.add_argument('-e', '--episode', type=int, default=0, help="Указать эпизод")
parser.add_argument('-r', '--results', type=int, default=5, help="Количество результатов поиска, по умолчанию 5")
parser.add_argument('-f', '--fast', action="store_true", help='Быстрый запуск')
parser.add_argument('-l', '--latest', action="store_true", help='Открыть последнее аниме')
args = parser.parse_args()

#Создание путей для записи последнего просмотра
cache = Path.home() / '.cache/Anilibria'
latest = cache / 'latest.txt'
if not latest.exists():
  if not cache.exists():
    cache.mkdir()
  latest.touch()

#Обработка флага -l
if args.latest:
  subprocess.run(["mx", latest.read_text()])
  exit()

#Обработка флага -s
if args.search:
  searchPar = {'limit': args.results, 'f[search]': args.search, 'include': 'id,name.main,type.description,episodes_total'}
else:
  searchPar = {'limit': args.results, 'include': 'id,name.main,type.description,episodes_total'}
response = json.loads(requests.get('https://api.anilibria.app/api/v1/anime/catalog/releases/?', params=searchPar).text)
results = response['data']

while len(results) == 0:
  args.search = input('Ничего не найдено (⊙_⊙)\nВведите новый запрос: ')
  searchPar = {'limit': args.results, 'f[search]': args.search, 'include': 'id,name.main,type.description,episodes_total'}
  response = json.loads(requests.get('https://api.anilibria.app/api/v1/anime/catalog/releases/?', params=searchPar).text)
  results = response['data']

#Обработка флага -f
if args.fast:
  counter = 1
  for result in results:
    if result['type']['description'] == 'Фильм':
      print(f"{counter} {result['name']['main']} [{result['type']['description']}]")
    else:
      print(f"{counter} {result['name']['main']} ({result['episodes_total']}) [{result['type']['description']}]")
    counter += 1
  
  titleNumber = int(input("Введите номер тайтла: "))
  while len(results) < titleNumber:
    titleNumber = int(input("Слишком большой номер: "))

  if args.episode == 0:
    args.episode = int(input("Введите номер эпизода: "))
  while results[titleNumber - 1]['episodes_total'] < args.episode:
    args.episode = int(input("Слишком большой номер эпизода: "))
  
  title = results[titleNumber - 1]
  titlePar = {'include': 'episodes',\
  'exclude': 'episodes.id,episodes.opening,episodes.ending,episodes.preview,episodes.duration,episodes.rutube_id,episodes.youtube_id,episodes.updated_at,episodes.sort_order,episodes.release_id,episodes.name_english'}
  url = "https://api.anilibria.app/api/v1/anime/releases/" + str(title['id']) + "?"
  episodes = json.loads(requests.get(url, params=titlePar).text)['episodes']
  
  while episodes[args.episode - 1]['hls_' + args.quality] == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
  subprocess.run(["mx", episodes[args.episode - 1]['hls_' + args.quality]])
  latest.write_text(episodes[args.episode - 1]['hls_' + args.quality])
  exit()

#Отрисовка списка результатов
counter = 1
for result in results:
  print(counter, " ",\
  result['name']['main'],\
  ' [', result['type']['description'], ']',\
  sep="")
  counter += 1

titleNumber = int(input("Введите номер: "))
while len(results) < titleNumber:
  titleNumber = int(input("Слишком большой номер: "))

title = results[titleNumber - 1]
titlePar = {'include': 'episodes',\
'exclude': 'episodes.id,episodes.opening,episodes.ending,episodes.preview,episodes.duration,episodes.rutube_id,episodes.youtube_id,episodes.updated_at,episodes.sort_order,episodes.release_id,episodes.name_english'}
url = "https://api.anilibria.app/api/v1/anime/releases/" + str(title['id']) + "?"
episodes = json.loads(requests.get(url, params=titlePar).text)['episodes']

#Проверка. Если выбраный тайтл - фильм, запускает просмотр
if title['type']['description'] == 'Фильм':
  while episodes[0]['hls_' + args.quality] == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
  subprocess.run(["mx", episodes[0]['hls_' + args.quality]])
  latest.write_text(episodes[0]['hls_' + args.quality])

#Если нет отрисовывает список эпизодов
else:
  if args.episode == 0:
    for episode in episodes:
      if episode['name'] == None:
        print(episode['ordinal'])
      else:
        print(episode['ordinal'],\
        episode['name'])
    args.episode = int(input('Введите номер: '))
  while len(episodes) < args.episode:
    args.episode = int(input("Слишком большой номер эпизода: "))
  while episodes[args.episode - 1]['hls_' + args.quality] == None:
    args.quality = input(f"Качество {args.quality} недоступно, введите другое: ")
  subprocess.run(["mx", episodes[args.episode - 1]['hls_' + args.quality]])
  latest.write_text(episodes[args.episode - 1]['hls_' + args.quality])
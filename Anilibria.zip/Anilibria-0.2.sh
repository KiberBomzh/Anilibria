#!/usr/bin/env bash

function getQuality() {
  #$1 - Id, $2 - номер эпизода
  #Получение id каждого эпизода
  epIds=($(\
    curl -s --get\
     --data-urlencode "include=episodes.id"\
     "https://api.anilibria.app/api/v1/anime/releases/$1?"\
      -H 'accept: application/json'\
      | jq -r ".episodes[] | .id"\
  ))
  #Получение ссылок на эпизод
  links=($(\
    curl -s --get\
     --data-urlencode 'exclude=id,name,ordinal,opening,ending,preview,duration,rutube_id,youtube_id,updated_at,sort_order,release_id,name_english,release'\
     "https://api.anilibria.app/api/v1/anime/releases/episodes/${epIds[$(($2 - 1))]}/?"\
     -H 'accept: application/json'\
     | jq -r ".hls_480, .hls_720, .hls_1080"
  ))
  #Запрос качества от пользователя
  qualities=(480 720 1080)
  counter=0
  echo "Качество доступно: "
  for link in ${!links[*]}
  do
    if [ link != 'null' ]; then
      echo "$((counter + 1)). ${qualities[$counter]}"
      ((counter++))
    fi
  done
  read -p "Введите номер: " chQ
  #Старт плеера
  mpv ${links[$((chQ - 1))]}
}

#Поиск тайтла, запись результатов в переменную
searchResults=$(\
curl -s --get\
 --data-urlencode "limit=20"\
 --data-urlencode "f[search]=$1"\
 --data-urlencode "include=id,name.main,episodes_total,type.description"\
 "https://api.anilibria.app/api/v1/anime/catalog/releases/?"\
 -H 'accept: application/json'\
)

#Сортировка результатов в три массива
id=($(echo $searchResults | jq '.data[] | .id'))
totalEpisodes=($(echo $searchResults | jq '.data[] | .episodes_total'))
mapfile name < <(echo $searchResults | jq -r '.data[] | .name.main')
type=($(echo $searchResults | jq -r '.data[] | .type.description'))

#Вывод найденых результатов
for var in ${!id[*]}
do
  if [ ${totalEpisodes[$var]} == 'null' ]; then
    echo\
     $(($var + 1))\
     ${name[$var]}\
     '['${type[$var]}']'
  elif [ ${type[$var]} == 'Фильм' ]; then
    echo\
     $(($var + 1))\
     ${name[$var]}\
     '['${type[$var]}']'
  else
    echo\
     $(($var + 1))\
     ${name[$var]}\
     '('${totalEpisodes[$var]}')'\
     '['${type[$var]}']'
  fi
done

#Запрос номера результата
read -p "Пункт со списка: " chId
#Проверка чтоб номер не превышал количество результатов
if [ $chId -le ${#id[*]} ]; then
  if [ ${type[$((chId - 1))]} == 'Фильм' ]; then
    getQuality ${id[$((chId - 1))]} 1
  else
    read -p "Номер серии: " chEpNum
    getQuality ${id[$((chId - 1))]} $chEpNum
  fi
else
  echo "Слишком большое число"
fi
